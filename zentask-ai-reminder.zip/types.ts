
export enum Priority {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high'
}

export enum Category {
  WORK = 'Work',
  PERSONAL = 'Personal',
  HOME = 'Home',
  HEALTH = 'Health',
  FINANCE = 'Finance',
  OTHER = 'Other'
}

export interface Task {
  id: string;
  title: string;
  description: string;
  dueDate: string; // ISO string
  priority: Priority;
  category: Category;
  completed: boolean;
  createdAt: string;
  reminderOffset?: number | null; // minutes before due date, null means use global default
}

export interface ReminderSettings {
  notificationsEnabled: boolean;
  leadTimeMinutes: number;
  soundEnabled: boolean;
}

export interface TaskStats {
  completed: number;
  pending: number;
  byCategory: { name: string; count: number }[];
}

export type ViewType = 'all' | 'today' | 'upcoming' | 'completed' | 'stats';
