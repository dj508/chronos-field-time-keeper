
export interface Technician {
  id: string;
  name: string;
  email: string;
  pin: string;
}

export interface Customer {
  id: string;
  name: string;
  representative?: string;
  address?: string;
  contact?: string;
  color: string;
}

export interface Project {
  id: string;
  customerId: string;
  name: string; // Serial Number / Tag
  mcMake?: string;
  mcType?: string;
  yearOfMfg?: string;
  runningHours?: string;
}

export interface Task {
  id: string;
  name: string;
  description?: string;
  completed?: boolean;
}

export interface ActivityType {
  id: string;
  name: string;
  color: string;
}

export interface EntryStep {
  activityId: string;
  description: string;
  startTime?: number;
  endTime?: number;
}

export interface TimeEntry {
  id: string;
  jobId: string;
  customerId: string;
  projectId?: string;
  steps: [EntryStep, EntryStep, EntryStep];
  checkIn: number;
  checkOut?: number;
  isSynced?: boolean;
  technicianName?: string;
  technicianEmail?: string;
}

export type ThemeMode = 'light' | 'dark';
export type AppView = 'dashboard' | 'customers' | 'history' | 'settings';
