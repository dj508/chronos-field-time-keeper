
import { Customer, TimeEntry, Project, Task, ActivityType, ThemeMode, Technician } from '../types';

const STORAGE_KEYS = {
  CUSTOMERS: 'chronos_customers',
  PROJECTS: 'chronos_projects',
  TASKS: 'chronos_tasks',
  ENTRIES: 'chronos_entries',
  ACTIVE_SESSION: 'chronos_active_session',
  ACTIVITY_TYPES: 'chronos_activity_types',
  REQUEST_TYPES: 'chronos_request_types',
  THEME_COLOR: 'chronos_theme_color',
  THEME_TEXT_COLOR: 'chronos_theme_text_color',
  THEME_BG_COLOR: 'chronos_theme_bg_color',
  THEME_CARD_COLOR: 'chronos_theme_card_color',
  THEME_NAV_COLOR: 'chronos_theme_nav_color',
  THEME_MODE: 'chronos_theme_mode',
  TECH_NAME: 'chronos_tech_name',
  TECH_EMAIL: 'chronos_tech_email',
  LOGGED_IN_TECH: 'chronos_logged_in_tech',
  REMEMBER_ME: 'chronos_remember_me',
  TECHNICIANS: 'chronos_local_technicians',
  PHASE_LABELS: 'chronos_phase_labels',
  LAST_BACKUP: 'chronos_last_backup'
};

const safeParse = <T>(key: string, defaultValue: T): T => {
  try {
    const data = localStorage.getItem(key) || sessionStorage.getItem(key);
    return data ? JSON.parse(data) : defaultValue;
  } catch (e) {
    console.error(`Error parsing storage key: ${key}`, e);
    return defaultValue;
  }
};

export const StorageService = {
  saveCustomers: (customers: Customer[]) => {
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
  },
  getCustomers: (): Customer[] => {
    return safeParse(STORAGE_KEYS.CUSTOMERS, []);
  },
  saveProjects: (projects: Project[]) => {
    localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(projects));
  },
  getProjects: (): Project[] => {
    return safeParse(STORAGE_KEYS.PROJECTS, []);
  },
  saveEntries: (entries: TimeEntry[]) => {
    localStorage.setItem(STORAGE_KEYS.ENTRIES, JSON.stringify(entries));
  },
  getEntries: (): TimeEntry[] => {
    return safeParse(STORAGE_KEYS.ENTRIES, []);
  },
  saveActiveSession: (entry: TimeEntry | null) => {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_SESSION, JSON.stringify(entry));
  },
  getActiveSession: (): TimeEntry | null => {
    return safeParse(STORAGE_KEYS.ACTIVE_SESSION, null);
  },
  saveThemeColor: (color: string) => {
    localStorage.setItem(STORAGE_KEYS.THEME_COLOR, color);
  },
  getThemeColor: (): string => {
    return localStorage.getItem(STORAGE_KEYS.THEME_COLOR) || '#6366f1';
  },
  saveTextColor: (color: string) => {
    localStorage.setItem(STORAGE_KEYS.THEME_TEXT_COLOR, color);
  },
  getTextColor: (): string => {
    return localStorage.getItem(STORAGE_KEYS.THEME_TEXT_COLOR) || ''; 
  },
  saveBgColor: (color: string) => {
    localStorage.setItem(STORAGE_KEYS.THEME_BG_COLOR, color);
  },
  getBgColor: (): string => {
    return localStorage.getItem(STORAGE_KEYS.THEME_BG_COLOR) || ''; 
  },
  saveCardColor: (color: string) => {
    localStorage.setItem(STORAGE_KEYS.THEME_CARD_COLOR, color);
  },
  getCardColor: (): string => {
    return localStorage.getItem(STORAGE_KEYS.THEME_CARD_COLOR) || '';
  },
  saveThemeMode: (mode: ThemeMode) => {
    localStorage.setItem(STORAGE_KEYS.THEME_MODE, mode);
  },
  getThemeMode: (): ThemeMode => {
    return (localStorage.getItem(STORAGE_KEYS.THEME_MODE) as ThemeMode) || 'dark';
  },
  saveTechSession: (tech: Technician | null, remember: boolean) => {
    const storage = remember ? localStorage : sessionStorage;
    if (tech) {
      storage.setItem(STORAGE_KEYS.LOGGED_IN_TECH, JSON.stringify(tech));
      localStorage.setItem(STORAGE_KEYS.REMEMBER_ME, JSON.stringify(remember));
    } else {
      localStorage.removeItem(STORAGE_KEYS.LOGGED_IN_TECH);
      sessionStorage.removeItem(STORAGE_KEYS.LOGGED_IN_TECH);
      localStorage.removeItem(STORAGE_KEYS.REMEMBER_ME);
    }
  },
  getTechSession: (): Technician | null => {
    return safeParse(STORAGE_KEYS.LOGGED_IN_TECH, null);
  },
  getRememberMe: (): boolean => {
    return safeParse(STORAGE_KEYS.REMEMBER_ME, false);
  },
  saveLocalTechnicians: (techs: Technician[]) => {
    localStorage.setItem(STORAGE_KEYS.TECHNICIANS, JSON.stringify(techs));
  },
  getLocalTechnicians: (): Technician[] => {
    return safeParse(STORAGE_KEYS.TECHNICIANS, []);
  },
  savePhaseLabels: (labels: string[]) => {
    localStorage.setItem(STORAGE_KEYS.PHASE_LABELS, JSON.stringify(labels));
  },
  getPhaseLabels: (): string[] => {
    return safeParse(STORAGE_KEYS.PHASE_LABELS, ["Transit In", "Field Operations", "Transit Return"]);
  },
  saveLastBackup: (timestamp: number) => {
    localStorage.setItem(STORAGE_KEYS.LAST_BACKUP, timestamp.toString());
  },
  getLastBackup: (): number => {
    return parseInt(localStorage.getItem(STORAGE_KEYS.LAST_BACKUP) || '0');
  }
};
